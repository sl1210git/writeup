package com.example.entityapi.controller;

import com.example.entityapi.entity.StoreProc;
import com.example.entityapi.repository.StoreProcRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/storeprocs")
public class StoreProcController {

    @Autowired
    private StoreProcRepository storeProcRepository;

    @GetMapping
    public List<StoreProc> getAllStoreProcs() {
        return storeProcRepository.findAll();
    }

    @PostMapping
    public StoreProc createStoreProc(@RequestBody StoreProc storeProc) {
        return storeProcRepository.save(storeProc);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StoreProc> getStoreProcById(@PathVariable Long id) {
        return storeProcRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<StoreProc> updateStoreProc(@PathVariable Long id, @RequestBody StoreProc updated) {
        return storeProcRepository.findById(id).map(sp -> {
            sp.setComponentName(updated.getComponentName());
            sp.setXmlTagName(updated.getXmlTagName());
            return ResponseEntity.ok(storeProcRepository.save(sp));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStoreProc(@PathVariable Long id) {
        storeProcRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}