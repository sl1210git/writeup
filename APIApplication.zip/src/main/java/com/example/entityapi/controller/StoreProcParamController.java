package com.example.entityapi.controller;

import com.example.entityapi.entity.StoreProcParam;
import com.example.entityapi.repository.StoreProcParamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/storeprocparams")
public class StoreProcParamController {

    @Autowired
    private StoreProcParamRepository storeProcParamRepository;

    @GetMapping
    public List<StoreProcParam> getAllParams() {
        return storeProcParamRepository.findAll();
    }

    @PostMapping
    public StoreProcParam createParam(@RequestBody StoreProcParam param) {
        return storeProcParamRepository.save(param);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StoreProcParam> getParamById(@PathVariable Long id) {
        return storeProcParamRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<StoreProcParam> updateParam(@PathVariable Long id, @RequestBody StoreProcParam updated) {
        return storeProcParamRepository.findById(id).map(p -> {
            p.setParamName(updated.getParamName());
            p.setParamValue(updated.getParamValue());
            return ResponseEntity.ok(storeProcParamRepository.save(p));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteParam(@PathVariable Long id) {
        storeProcParamRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}