package com.example.entityapi.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Portfolio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long portfolioId;
    private String portfolioName;
    private String portfolioFullName;

    @ManyToOne
    @JoinColumn(name = "group_id")
    private Group group;

    @OneToMany(mappedBy = "portfolio", cascade = CascadeType.ALL)
    private List<StoreProc> storeProcMap;

    // Getters and Setters
}