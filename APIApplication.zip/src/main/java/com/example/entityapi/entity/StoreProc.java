package com.example.entityapi.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class StoreProc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long storeProcId;
    private String componentName;
    private String xmlTagName;

    @ManyToOne
    @JoinColumn(name = "portfolio_id")
    private Portfolio portfolio;

    @OneToMany(mappedBy = "storeProc", cascade = CascadeType.ALL)
    private List<StoreProcParam> storeProcParamMap;

    // Getters and Setters
}