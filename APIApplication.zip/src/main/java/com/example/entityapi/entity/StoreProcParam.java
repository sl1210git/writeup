package com.example.entityapi.entity;

import jakarta.persistence.*;

@Entity
public class StoreProcParam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long storeProcParamId;
    private String paramName;
    private String paramValue;

    @ManyToOne
    @JoinColumn(name = "store_proc_id")
    private StoreProc storeProc;

    // Getters and Setters
}