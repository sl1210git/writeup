package com.example.entityapi.repository;

import com.example.entityapi.entity.StoreProcParam;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreProcParamRepository extends JpaRepository<StoreProcParam, Long> {}