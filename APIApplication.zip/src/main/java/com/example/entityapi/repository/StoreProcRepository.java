package com.example.entityapi.repository;

import com.example.entityapi.entity.StoreProc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreProcRepository extends JpaRepository<StoreProc, Long> {}