import React from "react";
import GroupComponent from "./components/GroupComponent";

function App() {
    return (
        <div>
            <h1>Entity API UI</h1>
            <GroupComponent />
        </div>
    );
}

export default App;