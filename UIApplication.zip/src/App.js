import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import GroupComponent from "./components/GroupComponent";
import PortfolioComponent from "./components/PortfolioComponent";
import StoreProcComponent from "./components/StoreProcComponent";
import StoreProcParamComponent from "./components/StoreProcParamComponent";

function App() {
    return (
        <Router>
            <div>
                <h1>Entity API UI</h1>
                <nav>
                    <ul>
                        <li><Link to="/groups">Groups</Link></li>
                        <li><Link to="/portfolios">Portfolios</Link></li>
                        <li><Link to="/storeprocs">Store Procedures</Link></li>
                        <li><Link to="/storeprocparams">StoreProc Params</Link></li>
                    </ul>
                </nav>
                <Routes>
                    <Route path="/groups" element={<GroupComponent />} />
                    <Route path="/portfolios" element={<PortfolioComponent />} />
                    <Route path="/storeprocs" element={<StoreProcComponent />} />
                    <Route path="/storeprocparams" element={<StoreProcParamComponent />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;