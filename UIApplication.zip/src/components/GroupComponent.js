import React, { useEffect, useState } from "react";
import GroupService from "../services/GroupService";

function GroupComponent() {
    const [groups, setGroups] = useState([]);
    const [groupName, setGroupName] = useState("");

    useEffect(() => {
        loadGroups();
    }, []);

    const loadGroups = () => {
        GroupService.getGroups().then((response) => {
            setGroups(response.data);
        });
    };

    const createGroup = () => {
        GroupService.createGroup({ groupName }).then(() => {
            setGroupName("");
            loadGroups();
        });
    };

    return (
        <div>
            <h2>Groups</h2>
            <input
                type="text"
                placeholder="Group Name"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
            />
            <button onClick={createGroup}>Add Group</button>
            <ul>
                {groups.map((group) => (
                    <li key={group.groupId}>{group.groupName}</li>
                ))}
            </ul>
        </div>
    );
}

export default GroupComponent;