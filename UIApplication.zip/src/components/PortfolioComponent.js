import React, { useEffect, useState } from "react";
import PortfolioService from "../services/PortfolioService";

function PortfolioComponent() {
    const [portfolios, setPortfolios] = useState([]);
    const [portfolioName, setPortfolioName] = useState("");
    const [portfolioFullName, setPortfolioFullName] = useState("");

    useEffect(() => {
        loadPortfolios();
    }, []);

    const loadPortfolios = () => {
        PortfolioService.getPortfolios().then((response) => {
            setPortfolios(response.data);
        });
    };

    const createPortfolio = () => {
        PortfolioService.createPortfolio({
            portfolioName,
            portfolioFullName
        }).then(() => {
            setPortfolioName("");
            setPortfolioFullName("");
            loadPortfolios();
        });
    };

    return (
        <div>
            <h2>Portfolios</h2>
            <input
                type="text"
                placeholder="Portfolio Name"
                value={portfolioName}
                onChange={(e) => setPortfolioName(e.target.value)}
            />
            <input
                type="text"
                placeholder="Full Name"
                value={portfolioFullName}
                onChange={(e) => setPortfolioFullName(e.target.value)}
            />
            <button onClick={createPortfolio}>Add Portfolio</button>
            <ul>
                {portfolios.map((portfolio) => (
                    <li key={portfolio.portfolioId}>
                        {portfolio.portfolioName} - {portfolio.portfolioFullName}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default PortfolioComponent;