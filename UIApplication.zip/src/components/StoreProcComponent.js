import React, { useEffect, useState } from "react";
import StoreProcService from "../services/StoreProcService";

function StoreProcComponent() {
    const [storeProcs, setStoreProcs] = useState([]);
    const [componentName, setComponentName] = useState("");
    const [xmlTagName, setXmlTagName] = useState("");

    useEffect(() => {
        loadStoreProcs();
    }, []);

    const loadStoreProcs = () => {
        StoreProcService.getStoreProcs().then((response) => {
            setStoreProcs(response.data);
        });
    };

    const createStoreProc = () => {
        StoreProcService.createStoreProc({
            componentName,
            xmlTagName
        }).then(() => {
            setComponentName("");
            setXmlTagName("");
            loadStoreProcs();
        });
    };

    return (
        <div>
            <h2>Store Procedures</h2>
            <input
                type="text"
                placeholder="Component Name"
                value={componentName}
                onChange={(e) => setComponentName(e.target.value)}
            />
            <input
                type="text"
                placeholder="XML Tag Name"
                value={xmlTagName}
                onChange={(e) => setXmlTagName(e.target.value)}
            />
            <button onClick={createStoreProc}>Add StoreProc</button>
            <ul>
                {storeProcs.map((sp) => (
                    <li key={sp.storeProcId}>
                        {sp.componentName} - {sp.xmlTagName}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default StoreProcComponent;