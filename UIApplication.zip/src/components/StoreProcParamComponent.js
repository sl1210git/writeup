import React, { useEffect, useState } from "react";
import StoreProcParamService from "../services/StoreProcParamService";

function StoreProcParamComponent() {
    const [params, setParams] = useState([]);
    const [paramName, setParamName] = useState("");
    const [paramValue, setParamValue] = useState("");

    useEffect(() => {
        loadParams();
    }, []);

    const loadParams = () => {
        StoreProcParamService.getParams().then((response) => {
            setParams(response.data);
        });
    };

    const createParam = () => {
        StoreProcParamService.createParam({
            paramName,
            paramValue
        }).then(() => {
            setParamName("");
            setParamValue("");
            loadParams();
        });
    };

    return (
        <div>
            <h2>Store Procedure Params</h2>
            <input
                type="text"
                placeholder="Param Name"
                value={paramName}
                onChange={(e) => setParamName(e.target.value)}
            />
            <input
                type="text"
                placeholder="Param Value"
                value={paramValue}
                onChange={(e) => setParamValue(e.target.value)}
            />
            <button onClick={createParam}>Add Param</button>
            <ul>
                {params.map((p) => (
                    <li key={p.storeProcParamId}>
                        {p.paramName}: {p.paramValue}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default StoreProcParamComponent;