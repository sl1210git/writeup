import axios from "axios";

const API_URL = "http://localhost:8080/api/groups";

class GroupService {
    getGroups() {
        return axios.get(API_URL);
    }

    createGroup(group) {
        return axios.post(API_URL, group);
    }
}

export default new GroupService();