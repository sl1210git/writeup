import axios from "axios";

const API_URL = "http://localhost:8080/api/portfolios";

class PortfolioService {
    getPortfolios() {
        return axios.get(API_URL);
    }

    createPortfolio(portfolio) {
        return axios.post(API_URL, portfolio);
    }
}

export default new PortfolioService();