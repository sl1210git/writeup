import axios from "axios";

const API_URL = "http://localhost:8080/api/storeprocparams";

class StoreProcParamService {
    getParams() {
        return axios.get(API_URL);
    }

    createParam(param) {
        return axios.post(API_URL, param);
    }
}

export default new StoreProcParamService();